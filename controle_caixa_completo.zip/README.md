# Sistema de Controle de Caixa

Aplicação web simples em Flask para controle de entradas e saídas de caixa com exportação para Excel.

## Como rodar localmente
```bash
pip install -r requirements.txt
python app.py
```

Acesse em `http://localhost:5000`

Feito para deploy no Render.com